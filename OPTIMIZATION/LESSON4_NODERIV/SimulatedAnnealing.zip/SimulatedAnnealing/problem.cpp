#include "problem.h"

Problem::Problem(int n)
{
    dimension = n;
    left.resize(dimension);
    right.resize(dimension);
}

int Problem::getDimension() const
{
    return dimension;
}

Data Problem::getSample()
{
    Data x;
    x.resize(dimension);
    double r;
    for (int i = 0; i < dimension; i++)
    {
        //r = (rand() * 1.0) / RAND_MAX;
        r = ((double)rand()/(double)RAND_MAX);
        if (r < 0)
            r = -r;
        x[i] = left[i] + (right[i] - left[i]) * r;
    }
    return x;
}
void Problem::setLeftMargin(Data &x)
{
    left = x;
}

void Problem::setRightMargin(Data &x)
{
    right = x;
}
Data Problem::getLeftMargin() const
{
    return left;
}

Data Problem::getRightMargin() const
{
    return right;
}

double Problem::grms(Data &x)
{
    Data g = gradient(x);
    int i;
    double s = 0.0;
    for (i = 0; i < x.size(); i++)
        s = s + g[i] * g[i];
    return sqrt(s / x.size());
}

double Problem::statFunmin(Data &x)
{
    ++functioncalls;
    return funmin(x);
}

void    Problem::resetFunctionCalls()
{
    functioncalls=0;
}

int     Problem::getFunctionCalls() const
{
    return functioncalls;
}

Problem::~Problem()
{
}
