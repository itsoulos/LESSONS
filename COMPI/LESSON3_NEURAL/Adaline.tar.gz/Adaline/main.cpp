# include <adaline.h>
int main(int argc, char *argv[])
{
    Dataset train("../PerceptronData/function.train");
    Dataset test("../PerceptronData/function.test");
    Adaline ada;
    ada.setTrainSet(&train);
    ada.setTestSet(&test);
    ada.train();
    double e=ada.getTestError();
    double c=ada.getClassError();
    int i;
    for(i=0;i<test.count();i++)
    {
        Data pattern=test.getXPoint(i);
        pattern.push_back(1.0);
        double value=ada.getOutput(pattern);
        printf("%lf %lf %lf \n",pattern[0],test.getYPoint(i),value);
    }
   return 0;
}
