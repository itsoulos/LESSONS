#include "perceptron.h"
# include <stdlib.h>
# include <stdio.h>
# include <math.h>
Perceptron::Perceptron()
{
    n=0.1;
    emax=100;
    trainSet=NULL;
    testSet=NULL;
}

void    Perceptron::setTrainSet(Dataset *t)
{
    trainSet=t;
    weight.resize(t->dimension()+1);
    //randomize weights
    int i;
    for(i=0;i<weight.size();i++)
        weight[i]=0.1 *(rand() * 1.0/RAND_MAX);
}

void    Perceptron::setTestSet(Dataset *t)
{
    testSet=t;
}

void    Perceptron::setN(double mn)
{
    if(mn>0 && mn<1) n=mn;
}

double  Perceptron::getN() const
{
    return n;
}

void    Perceptron::setEmax(int e)
{
    if(e>0) emax=e;
}

int     Perceptron::getEmax() const
{
    return emax;
}

double  Perceptron::product(Data x,Data y)
{
    double sum=0.0;
    int i;
    for(i=0;i<x.size();i++)
        sum=sum+x[i]*y[i];
    return sum;
}

void  Perceptron::train()
{
    int e;
    for(e=1;e<=emax;e++)
    {
        int i;
        Data oldWeights=weight;
        for(i=0;i<trainSet->count();i++)
        {
            Data pattern=trainSet->getXPoint(i);
            double yx=trainSet->getYPoint(i);
           pattern.push_back(1.0);
            double ux=product(pattern,weight);
            double ox=ux>0?1.0:-1.0;
            int j;
            for(j=0;j<weight.size();j++)
                weight[j]=weight[j]+n*(yx-ox)*pattern[j];
        }
        double dist=distance(oldWeights,weight);
        if(dist<1e-5) break;
    }
}

double  Perceptron::distance(Data x,Data y)
{
    double sum=0.0;
    int i;
    for(i=0;i<x.size();i++)
        sum=sum+(x[i]-y[i])*(x[i]-y[i]);
    return sum;
}

double  Perceptron::getClass(Data pattern)
{
    pattern.push_back(1.0);
    double ux=product(pattern,weight);
    double ox=ux>0?1.0:-1.0;
    return ox;
}

double  Perceptron::testError()
{
    int i;
    int missed=0;
    for(i=0;i<testSet->count();i++)
    {
        double yx=testSet->getYPoint(i);
        double px=getClass(testSet->getXPoint(i));
        if(fabs(yx-px)>1e-5) missed++;
    }
    return missed*100.0/testSet->count();
}
