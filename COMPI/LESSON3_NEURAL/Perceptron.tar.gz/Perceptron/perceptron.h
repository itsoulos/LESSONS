#ifndef PERCEPTRON_H
#define PERCEPTRON_H
# include <dataset.h>

class Perceptron
{
private:
    Dataset *trainSet;
    Dataset *testSet;
    double n;//rythmos mathisis
    Data weight;
    int  emax;
public:
    Perceptron();
    void setTrainSet(Dataset *t);
    void setTestSet(Dataset *t);
    void setN(double mn);
    double getN() const;
    void setEmax(int e);
    int  getEmax() const;
    void train();
    double getClass(Data pattern);
    double testError();
    double product(Data x,Data y);
    double distance(Data x,Data y);
};

#endif // PERCEPTRON_H
